package com.test.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;

import com.test.entity.Stock;
import com.test.model.PagingHeaders;
import com.test.model.PagingResponse;
import com.test.repository.StockRepository;
import com.test.service.impl.StockServiceImpl;

@SpringBootTest
public class StockServiceTest {

	private StockServiceImpl stockServiceimpl;
	private StockRepository stockRepository = mock(StockRepository.class);

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.stockServiceimpl = new StockServiceImpl(stockRepository);
	}

	@Test
	public void get_should_return_the_entity() {
		// Given
		when(stockRepository.findById((long) eq(1))).thenReturn(
				Optional.of(Builder.stock(1, "WALLYS", "IRIS", "Small", "Tunisia", LocalDate.of(2006, 8, 29))));

		// When
		Stock s = stockServiceimpl.getStockById((long) 1);

		// Then
		assertThat(1, equalTo(s.getId()));

	}

	@Test
	public void get_by_specification_should_return_entities_list() {
		// Given
		Specification querySpec = mock(Specification.class);
		Sort sort = mock(Sort.class);
		when(stockRepository.findAll(querySpec, sort)).thenReturn(
				Arrays.asList(Builder.stock(1, "WALLYS", "IRIS", "Small", "Tunisia", LocalDate.of(2006, 8, 29)),
						Builder.stock(2, "Honda", "Civic", "Small", "Japan", LocalDate.of(1967, 9, 16))));

		// When
		List<Stock> foundstocks = stockServiceimpl.get(querySpec, sort);

		// Then
		verify(stockRepository, times(1)).findAll(querySpec, sort);
		assertThat(2, equalTo(foundstocks.size()));

	}

	@Test
	public void get_by_specification_and_pagination_should_return_paged_entities_list() {
		// Given
		Specification querySpec = mock(Specification.class);
		Sort sort = mock(Sort.class);
		HttpHeaders headers = new HttpHeaders();
		headers.add(PagingHeaders.PAGE_NUMBER.getName(), String.valueOf(0));
		headers.add(PagingHeaders.PAGE_SIZE.getName(), String.valueOf(2));

		PageRequest pageRequest = PageRequest.of(0, 2, sort);

		Page<Stock> stocks = Mockito.mock(Page.class);
		when(stockRepository.findAll(any(), (Pageable) any())).thenReturn(stocks);

		// When
		stockServiceimpl.get(querySpec, headers, sort);

		// Then
		verify(stockRepository, times(1)).findAll(querySpec, pageRequest);
	}

	@Test
	public void get_by_specification_and_sort_should_return_entities_list() {
		// Given
		Specification querySpec = mock(Specification.class);
		HttpHeaders headers = new HttpHeaders();
		headers.add(PagingHeaders.COUNT.getName(), String.valueOf(0));
		Sort sort = mock(Sort.class);

		List<Stock> stockList = Arrays.asList(
				Builder.stock(1, "WALLYS", "IRIS", "Small", "Tunisia", LocalDate.of(2006, 8, 29)),
				Builder.stock(2, "Honda", "Civic", "Small", "Japan", LocalDate.of(1967, 9, 16)),
				Builder.stock(3, "Ford", "Escort", "Small", "USA", LocalDate.of(1930, 12, 02)));

		when(stockRepository.findAll(any(), (Sort) any())).thenReturn(stockList);

		// When
		PagingResponse sortedList = stockServiceimpl.get(querySpec, headers, sort);

		// Then
		verify(stockRepository, times(1)).findAll(querySpec, sort);
		assertThat(0L, equalTo(sortedList.getPageNumber()));
		assertThat(0L, equalTo(sortedList.getPageSize()));
	}
}
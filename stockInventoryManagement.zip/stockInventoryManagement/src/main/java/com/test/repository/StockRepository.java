package com.test.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.test.entity.Stock;

@Repository
public interface StockRepository extends PagingAndSortingRepository<Stock, Long>, JpaSpecificationExecutor<Stock> {

}

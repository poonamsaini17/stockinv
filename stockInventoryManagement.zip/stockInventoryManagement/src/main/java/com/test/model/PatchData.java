package com.test.model;

public class PatchData {

	public enum OperationEnum {

		UPDATE("UPDATE");

		private String value;

		OperationEnum(String value) {
			this.value = value;
		}
	}

	private OperationEnum operation;

	private String property;

	private String value;

	public OperationEnum getOperation() {
		return operation;
	}

	public void setOperation(OperationEnum operation) {
		this.operation = operation;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}

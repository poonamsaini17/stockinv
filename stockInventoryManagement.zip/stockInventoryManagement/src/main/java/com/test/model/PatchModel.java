package com.test.model;

import java.util.ArrayList;
import java.util.List;

public class PatchModel {

	private List<PatchData> patchData;

	public PatchModel patchData(List<PatchData> patchData) {
		this.patchData = patchData;
		return this;
	}

	public PatchModel addPatchDataItem(PatchData patchDataItem) {
		if (this.patchData == null) {
			this.patchData = new ArrayList<PatchData>();
		}
		this.patchData.add(patchDataItem);
		return this;
	}

	public List<PatchData> getPatchData() {
		return patchData;
	}

	public void setPatchData(List<PatchData> patchData) {
		this.patchData = patchData;
	}

}

package com.test.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mak.springbootefficientsearchapi.entity.utils.PagingHeaders;
import com.test.entity.Stock;
import com.test.model.PagingResponse;
import com.test.model.PatchModel;
import com.test.service.StockService;

import net.kaczmarzyk.spring.data.jpa.domain.Equal;
import net.kaczmarzyk.spring.data.jpa.domain.In;
import net.kaczmarzyk.spring.data.jpa.domain.Like;
import net.kaczmarzyk.spring.data.jpa.web.annotation.And;
import net.kaczmarzyk.spring.data.jpa.web.annotation.Spec;

@RestController
@RequestMapping("/api/v1")
public class StockController {

	@Autowired
	private StockService stockService;

	@PostMapping("/stock")
	public Stock createStock(@RequestBody Stock stock) {
		return stockService.createStock(stock);
	}

	@GetMapping("/stocks")
	public List<Stock> getAllStocks() {
		return stockService.getAllStocks();
	}

	@GetMapping("/stock/{id}")
	public ResponseEntity<Stock> getStockById(@PathVariable(value = "id") Long stockId) {
		Stock stock = stockService.getStockById(stockId);
		return ResponseEntity.ok().body(stock);
	}

	@DeleteMapping("/stock/{id}")
	public Map<String, Boolean> deleteStock(@PathVariable(value = "id") Long stockId) {
		return stockService.deleteStock(stockId);
	}

	@PatchMapping("/stock/{id}")
	public ResponseEntity<Stock> updateStock(@RequestBody PatchModel patchModel,
			@PathVariable(value = "id") Long stockId) {
		Stock stock = stockService.updateStock(stockId, patchModel);
		return ResponseEntity.ok().body(stock);
	}

	public ResponseEntity<List<Stock>> get(
			@And({ @Spec(path = "stockNumber", params = "stockNumber", spec = In.class),
					@Spec(path = "stockName", params = "stockName", spec = Like.class),
					@Spec(path = "purchasingPrice", params = "purchasingPrice", spec = In.class),
					@Spec(path = "purchasingDate", params = "purchasingDate", spec = Equal.class),
					@Spec(path = "quantity", params = "quantity", spec = In.class) }) Specification<Stock> spec,
			Sort sort, @RequestHeader HttpHeaders headers) {
		final PagingResponse response = stockService.get(spec, headers, sort);
		return new ResponseEntity<>(response.getElements(), returnHttpHeaders(response), HttpStatus.OK);
	}

	public HttpHeaders returnHttpHeaders(PagingResponse response) {
		HttpHeaders headers = new HttpHeaders();
		headers.set(PagingHeaders.COUNT.getName(), String.valueOf(response.getCount()));
		headers.set(PagingHeaders.PAGE_SIZE.getName(), String.valueOf(response.getPageSize()));
		headers.set(PagingHeaders.PAGE_OFFSET.getName(), String.valueOf(response.getPageOffset()));
		headers.set(PagingHeaders.PAGE_NUMBER.getName(), String.valueOf(response.getPageNumber()));
		headers.set(PagingHeaders.PAGE_TOTAL.getName(), String.valueOf(response.getPageTotal()));
		return headers;
	}
}

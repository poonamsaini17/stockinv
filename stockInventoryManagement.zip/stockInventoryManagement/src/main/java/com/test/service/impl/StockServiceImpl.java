package com.test.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.test.entity.Stock;
import com.test.exception.ResourceNotFoundException;
import com.test.model.PagingHeaders;
import com.test.model.PagingResponse;
import com.test.model.PatchData;
import com.test.model.PatchModel;
import com.test.repository.StockRepository;
import com.test.service.StockService;

@Service
public class StockServiceImpl implements StockService {

	@Autowired
	StockRepository stockRepository;

	@Autowired
	public StockServiceImpl(StockRepository stockRepository) {
		this.stockRepository = stockRepository;
	}

	@Override
	public Stock createStock(Stock stock) {
		return stockRepository.save(stock);
	}

	@Override
	public Stock getStockById(Long stockId) {
		if (stockId != null) {
			Optional<Stock> stock = stockRepository.findById(stockId);
			return stock.get();
		}
		throw new ResourceNotFoundException("Stock not found for this id :: " + stockId);
	}

	@Override
	public Map<String, Boolean> deleteStock(Long stockId) {
		Optional<Stock> stock = stockRepository.findById(stockId);
		stockRepository.delete(stock.get());
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

	@Override
	public Stock updateStock(Long stockId, PatchModel patchModel) {
		Optional<Stock> stock = stockRepository.findById(stockId);
		Stock stockFound = stock.get();
		Stock modifiedStock = (Stock) patchModel(stockFound, patchModel);
		Stock updateStock = stockRepository.save(modifiedStock);
		return updateStock;
	}

	private Object patchModel(Stock obj, PatchModel patchModel) {
		Object modifiedObject = obj;
		for (PatchData patchData : patchModel.getPatchData()) {
			modifiedObject = patchData(obj, patchData);
		}
		return modifiedObject;
	}

	private Object patchData(Stock obj, PatchData patchData) {
		Object modifiedItem = null;
		switch (patchData.getOperation()) {
		case UPDATE:
			modifiedItem = update(obj, patchData);
			break;
		default:
			System.err.println("Error");

		}
		return modifiedItem;
	}

	public Object update(Object obj, PatchData patchData) {

		BeanUtils.copyProperties(obj, patchData.getProperty(), patchData.getValue());
		return obj;

	}

	@Override
	public PagingResponse get(Specification<Stock> spec, HttpHeaders headers, Sort sort) {
		if (isRequestPaged(headers)) {
			return get(spec, buildPageRequest(headers, sort));
		} else {
			List<Stock> entities = get(spec, sort);
			return new PagingResponse((long) entities.size(), 0L, 0L, 0L, 0L, entities);
		}
	}

	private boolean isRequestPaged(HttpHeaders headers) {
		return headers.containsKey(PagingHeaders.PAGE_NUMBER.getName())
				&& headers.containsKey(PagingHeaders.PAGE_SIZE.getName());
	}

	private Pageable buildPageRequest(HttpHeaders headers, Sort sort) {
		int page = Integer.parseInt(Objects.requireNonNull(headers.get(PagingHeaders.PAGE_NUMBER.getName())).get(0));
		int size = Integer.parseInt(Objects.requireNonNull(headers.get(PagingHeaders.PAGE_SIZE.getName())).get(0));
		return PageRequest.of(page, size, sort);
	}

	public PagingResponse get(Specification<Stock> spec, Pageable pageable) {
		Page<Stock> page = stockRepository.findAll(spec, pageable);
		List<Stock> content = page.getContent();
		return new PagingResponse(page.getTotalElements(), (long) page.getNumber(), (long) page.getNumberOfElements(),
				pageable.getOffset(), (long) page.getTotalPages(), content);
	}

	public List<Stock> get(Specification<Stock> spec, Sort sort) {
		return stockRepository.findAll(spec, sort);
	}

}
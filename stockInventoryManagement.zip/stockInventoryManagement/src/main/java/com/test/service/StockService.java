package com.test.service;

import java.util.Map;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.test.entity.Stock;
import com.test.model.PagingResponse;
import com.test.model.PatchModel;

@Service
public interface StockService {

	Stock createStock(Stock stock);

	Stock getStockById(Long stockId);

	Map<String, Boolean> deleteStock(Long stockId);

	Stock updateStock(Long stockId, PatchModel patchModel);

	PagingResponse get(Specification<Stock> spec, HttpHeaders headers, Sort sort);

}
